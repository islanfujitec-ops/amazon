// painel.js — Painel web local para configurar e operar o Radar Petronect.
// Abra http://localhost:3333 no navegador do servidor.
//   - Palavras-chave (salva em config/palavras.txt)
//   - WhatsApp: mostra o QR na tela, status da conexao
//   - Grupo de destino (detecta pelo grupo ou digita o numero com DDD)
//   - Liga/desliga o radar e mostra os ultimos alertas/logs
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import express from "express";
import QRCode from "qrcode";

import { umCiclo } from "./index.js";
import { obterCliente, enviarMensagem, getEstado, getQrRaw } from "./whatsapp.js";
import { resetar, listarEncontradas, alternarMarcado } from "./store.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const RAIZ = path.join(__dirname, "..");
const PUBLIC_DIR = path.join(RAIZ, "public");
const PALAVRAS_FILE = path.join(RAIZ, "config", "palavras.txt");
const ENV_FILE = path.join(RAIZ, ".env");
const LOG_FILE = path.join(RAIZ, "logs", "radar.log");
const PORTA = Number(process.env.PAINEL_PORT || 3333);

// ---------- helpers de config ----------
function lerPalavras() {
  try {
    return fs.readFileSync(PALAVRAS_FILE, "utf8");
  } catch {
    return "";
  }
}
function salvarPalavras(texto) {
  fs.writeFileSync(PALAVRAS_FILE, String(texto ?? "").replace(/\r\n/g, "\n"), "utf8");
}

// Atualiza (ou cria) uma variavel no .env e no process.env (efeito imediato).
function setEnv(chave, valor) {
  process.env[chave] = valor;
  let txt = "";
  try {
    txt = fs.readFileSync(ENV_FILE, "utf8");
  } catch {
    /* cria novo */
  }
  const linha = `${chave}=${valor}`;
  const re = new RegExp(`^${chave}=.*$`, "m");
  txt = re.test(txt) ? txt.replace(re, linha) : (txt.replace(/\s*$/, "") + `\n${linha}\n`);
  fs.writeFileSync(ENV_FILE, txt, "utf8");
}

function lerLog(maxLinhas = 40) {
  try {
    const linhas = fs.readFileSync(LOG_FILE, "utf8").trim().split(/\r?\n/);
    return linhas.slice(-maxLinhas);
  } catch {
    return [];
  }
}

// ---------- controle do radar ----------
const radar = { ligado: false, timer: null, ocupado: false };

async function rodarCiclo() {
  if (radar.ocupado) return; // evita ciclos sobrepostos
  radar.ocupado = true;
  try {
    await umCiclo();
  } catch (e) {
    console.error("[painel] erro no ciclo:", e.message);
  } finally {
    radar.ocupado = false;
  }
}
function ligarRadar() {
  if (radar.ligado) return;
  radar.ligado = true;
  const intervaloMin = Number(process.env.INTERVALO_MIN || 15);
  rodarCiclo(); // primeiro ciclo imediato
  radar.timer = setInterval(rodarCiclo, intervaloMin * 60 * 1000);
}
function desligarRadar() {
  radar.ligado = false;
  if (radar.timer) clearInterval(radar.timer);
  radar.timer = null;
}

// ---------- servidor ----------
const app = express();
app.use(express.json());
app.use(express.static(PUBLIC_DIR));
app.get("/", (req, res) => res.sendFile(path.join(PUBLIC_DIR, "painel.html")));

app.get("/api/status", async (req, res) => {
  const wa = getEstado();
  let qrDataUrl = null;
  const qr = getQrRaw();
  if (qr) {
    try {
      qrDataUrl = await QRCode.toDataURL(qr, { margin: 1, width: 320 });
    } catch {
      /* ignora */
    }
  }
  res.json({
    whatsapp: wa,
    qrDataUrl,
    radarLigado: radar.ligado,
    radarOcupado: radar.ocupado,
    destino: process.env.WHATSAPP_DESTINO || "",
    intervaloMin: Number(process.env.INTERVALO_MIN || 15),
    estado: process.env.FILTRO_ESTADO || "",
    temChaveIa: !!(process.env.NVIDIA_API_KEY && process.env.NVIDIA_API_KEY.trim()),
    log: lerLog(),
  });
});

app.get("/api/palavras", (req, res) => res.json({ texto: lerPalavras() }));
app.post("/api/palavras", (req, res) => {
  try {
    salvarPalavras(req.body?.texto);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, erro: e.message });
  }
});

app.post("/api/config", (req, res) => {
  try {
    if (req.body?.destino !== undefined) setEnv("WHATSAPP_DESTINO", String(req.body.destino).trim());
    if (req.body?.intervaloMin !== undefined) setEnv("INTERVALO_MIN", String(Number(req.body.intervaloMin) || 15));
    if (req.body?.estado !== undefined) setEnv("FILTRO_ESTADO", String(req.body.estado).trim().toUpperCase());
    if (req.body?.nvidiaKey !== undefined && String(req.body.nvidiaKey).trim())
      setEnv("NVIDIA_API_KEY", String(req.body.nvidiaKey).trim());
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, erro: e.message });
  }
});

// Lista das oportunidades encontradas/enviadas (para marcar no painel).
app.get("/api/encontradas", (req, res) => res.json({ itens: listarEncontradas() }));
app.post("/api/marcar", (req, res) => {
  const m = alternarMarcado(String(req.body?.id || ""));
  res.json({ ok: m !== null, marcado: m });
});

// Inicia o WhatsApp (dispara o QR se ainda nao estiver pareado).
app.post("/api/whatsapp/conectar", (req, res) => {
  obterCliente().catch((e) => console.error("[painel] WhatsApp:", e.message));
  res.json({ ok: true });
});

// Usa o ultimo grupo detectado como destino.
app.post("/api/whatsapp/usar-grupo", (req, res) => {
  const g = getEstado().ultimoGrupo;
  if (!g?.id) return res.status(400).json({ ok: false, erro: "Nenhum grupo detectado ainda. Envie uma mensagem no grupo." });
  setEnv("WHATSAPP_DESTINO", g.id);
  res.json({ ok: true, destino: g.id, nome: g.nome });
});

// Extrai o codigo de convite de um link do WhatsApp (ou aceita so o codigo).
function codigoConvite(entrada) {
  const s = String(entrada || "").trim();
  const m = s.match(/chat\.whatsapp\.com\/([A-Za-z0-9_-]+)/i);
  if (m) return m[1];
  if (/^[A-Za-z0-9_-]{10,}$/.test(s)) return s; // colou so o codigo
  return null;
}

// Define o destino a partir de um LINK de convite de grupo.
app.post("/api/whatsapp/usar-link", async (req, res) => {
  try {
    const code = codigoConvite(req.body?.link);
    if (!code) return res.status(400).json({ ok: false, erro: "Link de grupo invalido. Cole algo como chat.whatsapp.com/XXXX" });
    const client = await obterCliente();
    let gid = null;
    let nome = "";
    try {
      // Entra no grupo pelo convite (garante que a conta seja membro para poder enviar).
      const r = await client.acceptInvite(code);
      gid = typeof r === "string" ? r : r?._serialized || r?.gid?._serialized || null;
    } catch {
      // Ja e membro (ou nao pode entrar): pega o id pela info do convite.
      const info = await client.getInviteInfo(code);
      gid = info?.id?._serialized || null;
      nome = info?.subject || "";
    }
    if (!gid || !String(gid).endsWith("@g.us")) throw new Error("Nao consegui resolver o grupo pelo link.");
    setEnv("WHATSAPP_DESTINO", gid);
    res.json({ ok: true, destino: gid, nome });
  } catch (e) {
    res.status(500).json({ ok: false, erro: e.message });
  }
});

app.post("/api/testar", async (req, res) => {
  try {
    const ack = await enviarMensagem(
      process.env.WHATSAPP_DESTINO,
      "✅ Teste do Radar Petronect (pelo Painel): se chegou, esta tudo certo."
    );
    res.json({ ok: true, ack });
  } catch (e) {
    res.status(500).json({ ok: false, erro: e.message });
  }
});

app.post("/api/radar/ligar", (req, res) => {
  if (!process.env.WHATSAPP_DESTINO) return res.status(400).json({ ok: false, erro: "Defina o destino (grupo ou numero) antes de ligar." });
  ligarRadar();
  res.json({ ok: true });
});
app.post("/api/radar/desligar", (req, res) => {
  desligarRadar();
  res.json({ ok: true });
});

// Esquece o historico e faz UMA varredura enviando as licitacoes que casam AGORA
// (util para ver resultado na hora, ou depois de mudar as palavras).
app.post("/api/reprocessar", async (req, res) => {
  if (!process.env.WHATSAPP_DESTINO) return res.status(400).json({ ok: false, erro: "Defina o destino (grupo ou numero) antes." });
  if (radar.ocupado) return res.status(409).json({ ok: false, erro: "Uma varredura ja esta em andamento. Tente de novo em 1 minuto." });
  radar.ocupado = true;
  const antes = process.env.ENVIAR_NA_PRIMEIRA;
  try {
    resetar();
    process.env.ENVIAR_NA_PRIMEIRA = "true"; // forca envio nesta rodada
    await umCiclo();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, erro: e.message });
  } finally {
    process.env.ENVIAR_NA_PRIMEIRA = antes ?? "false";
    radar.ocupado = false;
  }
});

app.listen(PORTA, () => {
  console.log(`\n================================================`);
  console.log(`  Painel do Radar Petronect no ar!`);
  console.log(`  Abra no navegador:  http://localhost:${PORTA}`);
  console.log(`================================================\n`);
});
