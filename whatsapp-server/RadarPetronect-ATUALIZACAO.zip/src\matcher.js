// matcher.js — filtro por palavras-chave.
// Normaliza texto (sem acento, minusculo) e verifica se o titulo/objeto
// contem QUALQUER uma das palavras configuradas.
//
// Fonte das palavras (nesta ordem):
//   1) config/palavras.txt  -> uma palavra/termo por linha (formato simples, recomendado)
//   2) config/keywords.json -> fallback antigo { "palavras": [...] }
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_DIR = path.join(__dirname, "..", "config");
const TXT_FILE = path.join(CONFIG_DIR, "palavras.txt");
const JSON_FILE = path.join(CONFIG_DIR, "keywords.json");

// Remove marcas de acento (faixa Unicode combinante U+0300..U+036F).
const ACENTOS = /[̀-ͯ]/g;

export function normalizar(texto) {
  return String(texto || "")
    .normalize("NFD")
    .replace(ACENTOS, "")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

export function carregarPalavras() {
  let brutas = [];
  if (fs.existsSync(TXT_FILE)) {
    // Uma por linha; ignora linhas vazias e comentarios (#).
    brutas = fs
      .readFileSync(TXT_FILE, "utf8")
      .split(/\r?\n/)
      .map((l) => l.trim())
      .filter((l) => l && !l.startsWith("#"));
  } else if (fs.existsSync(JSON_FILE)) {
    const raw = JSON.parse(fs.readFileSync(JSON_FILE, "utf8"));
    brutas = Array.isArray(raw) ? raw : raw.palavras || [];
  }
  // Remove duplicatas apos normalizar.
  const vistos = new Set();
  const lista = [];
  for (const p of brutas) {
    const n = normalizar(p);
    if (n && !vistos.has(n)) {
      vistos.add(n);
      lista.push(n);
    }
  }
  return lista;
}

// Monta um regex para o termo ja normalizado.
// - Termos curtos (<= 3 letras, ex.: "ex", "ptz", "h2s"): exigem PALAVRA EXATA
//   (evita casar "ex" dentro de "execucao", "flexivel" etc.).
// - Termos maiores: casam tambem plural/derivados (ex.: "camera" casa "cameras";
//   "inox" casa "inoxidavel").
function regexDoTermo(termo) {
  const escapado = termo.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const corpo = termo.length <= 3 ? `\\b${escapado}\\b` : `\\b${escapado}`;
  return new RegExp(corpo);
}

// Retorna a lista de palavras (originais normalizadas) que casaram (vazia = nao casou).
export function casar(oportunidade, palavras) {
  const alvo = normalizar(`${oportunidade.titulo || ""} ${oportunidade.objeto || ""}`);
  const encontradas = [];
  for (const p of palavras) {
    if (regexDoTermo(p).test(alvo)) encontradas.push(p);
  }
  return encontradas;
}
