// summarizer.js — gera um resumo curto em PT-BR via NVIDIA NIM.
// Reaproveita a mesma abordagem dos scripts nvidia-fallback do usuario:
// endpoint OpenAI-compativel + cadeia de modelos Nemotron 3 com retry.
import "dotenv/config";

const URL = "https://integrate.api.nvidia.com/v1/chat/completions";

// Cadeia de modelos (principal -> reservas). Mesma ordem dos scripts existentes.
const MODELOS = [
  { id: "nvidia/nemotron-3-super-120b-a12b", timeoutMs: 45000 },
  { id: "nvidia/nemotron-3-nano-30b-a3b", timeoutMs: 30000 },
  { id: "nvidia/nemotron-3-ultra-550b-a55b", timeoutMs: 60000 },
];

const SYSTEM =
  "Voce resume licitacoes/oportunidades da Petrobras (Petronect) em portugues do Brasil. " +
  "Escreva um resumo objetivo de 2 a 3 frases dizendo o que esta sendo contratado, " +
  "para quem interessa e algum detalhe relevante (prazo, local, modalidade) se houver. " +
  "Sem introducao, sem 'segue o resumo', apenas o texto.";

function comTimeout(ms) {
  const c = new AbortController();
  const t = setTimeout(() => c.abort(), ms);
  return { signal: c.signal, cancelar: () => clearTimeout(t) };
}

// Gera o resumo. Se a IA falhar em todos os modelos, devolve null
// (o chamador deve cair para o objeto original — nunca perder o alerta).
export async function resumir(oportunidade) {
  const key = process.env.NVIDIA_API_KEY;
  if (!key) {
    console.warn("[summarizer] NVIDIA_API_KEY ausente — enviando sem resumo IA.");
    return null;
  }

  const prompt =
    `Titulo: ${oportunidade.titulo || "(sem titulo)"}\n` +
    `Objeto/descricao: ${oportunidade.objeto || "(sem descricao)"}\n` +
    (oportunidade.modalidade ? `Modalidade: ${oportunidade.modalidade}\n` : "") +
    (oportunidade.orgao ? `Orgao/UO: ${oportunidade.orgao}\n` : "") +
    (oportunidade.prazo ? `Prazo: ${oportunidade.prazo}\n` : "") +
    `\nResuma em 2-3 frases.`;

  for (const m of MODELOS) {
    const { signal, cancelar } = comTimeout(m.timeoutMs);
    try {
      const resp = await fetch(URL, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${key}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: m.id,
          messages: [
            { role: "system", content: SYSTEM },
            { role: "user", content: prompt },
          ],
          temperature: 0.2,
          max_tokens: 400,
          stream: false,
        }),
        signal,
      });
      cancelar();
      if (!resp.ok) {
        console.warn(`[summarizer] ${m.id} respondeu HTTP ${resp.status}`);
        continue;
      }
      const data = await resp.json();
      let txt = data?.choices?.[0]?.message?.content?.trim();
      if (txt) {
        // Nemotron as vezes inclui bloco de raciocinio <think>...</think>; remove.
        txt = txt.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
        if (txt) return txt;
      }
    } catch (e) {
      cancelar();
      console.warn(`[summarizer] falha em ${m.id}: ${e.message}`);
    }
  }
  return null;
}

// Execucao direta para teste: node src/summarizer.js --test
if (process.argv[1] && process.argv[1].endsWith("summarizer.js") && process.argv.includes("--test")) {
  const exemplo = {
    titulo: "Contratacao de servicos de manutencao de valvulas industriais",
    objeto:
      "Prestacao de servicos de manutencao preventiva e corretiva de valvulas de seguranca e controle em unidade de refino, incluindo mao de obra e pecas.",
    modalidade: "Pregao Eletronico",
    prazo: "10 dias",
  };
  const r = await resumir(exemplo);
  console.log("\n=== RESUMO ===\n", r ?? "(IA indisponivel — usaria o objeto original)");
}
