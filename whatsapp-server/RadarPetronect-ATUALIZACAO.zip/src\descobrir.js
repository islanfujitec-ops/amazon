// descobrir.js — ferramenta de DIAGNOSTICO do portal Petronect.
// Abre o portal publico, registra links/botoes, frames e TODAS as respostas
// de rede em JSON (possiveis endpoints da lista de oportunidades) e salva
// tudo em data/descoberta/. Use o resultado para finalizar os seletores do
// scraper.js.
//
// Uso:
//   node src/descobrir.js            (headless)
//   node src/descobrir.js --ver      (com janela visivel — recomendado)
//
// Rode preferencialmente NA SUA MAQUINA (Brasil): o portal bloqueia IPs de fora
// do pais e usa protecao anti-bot que pode barrar execucao headless remota.
import { chromium } from "playwright";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const OUT = path.join(__dirname, "..", "data", "descoberta");
fs.mkdirSync(OUT, { recursive: true });

const HEADLESS = !process.argv.includes("--ver");
const ENTRADA =
  process.env.PETRONECT_URL || "https://www.petronect.com.br/irj/portal/anonymous";

const jsonHits = [];

function salvar(nome, conteudo) {
  fs.writeFileSync(path.join(OUT, nome), conteudo, "utf8");
}

const browser = await chromium.launch({ headless: HEADLESS });
const ctx = await browser.newContext({
  locale: "pt-BR",
  timezoneId: "America/Sao_Paulo",
  userAgent:
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36",
});
const page = await ctx.newPage();

// Intercepta respostas — guarda as que parecem dados (json / conteudo estruturado).
page.on("response", async (resp) => {
  try {
    const ct = resp.headers()["content-type"] || "";
    const url = resp.url();
    if (ct.includes("json") || /odata|search|oportun|cotac|licit/i.test(url)) {
      let corpo = "";
      try {
        corpo = (await resp.text()).slice(0, 2000);
      } catch {
        /* corpo indisponivel */
      }
      jsonHits.push({ url, status: resp.status(), contentType: ct, amostra: corpo });
    }
  } catch {
    /* ignora */
  }
});

console.log(`Abrindo ${ENTRADA} (headless=${HEADLESS})...`);
await page.goto(ENTRADA, { waitUntil: "networkidle", timeout: 90000 }).catch((e) => {
  console.log("Aviso ao carregar:", e.message);
});
await page.waitForTimeout(6000);

// 1) Links e botoes visiveis (para achar "Oportunidades Publicas" / "Acesso Publico").
const interativos = await page
  .evaluate(() => {
    const out = [];
    const push = (el, tipo) => {
      const txt = (el.innerText || el.value || el.title || "").trim().replace(/\s+/g, " ");
      const href = el.getAttribute?.("href") || "";
      if (txt || href) out.push({ tipo, txt: txt.slice(0, 80), href });
    };
    document.querySelectorAll("a").forEach((el) => push(el, "a"));
    document.querySelectorAll("button,input[type=button],input[type=submit]").forEach((el) =>
      push(el, "btn")
    );
    return out;
  })
  .catch(() => []);

// 2) Frames (SAP EP usa iframes aninhados).
const frames = page.frames().map((f) => ({ name: f.name(), url: f.url() }));

// 3) HTML e screenshot.
salvar("pagina.html", await page.content().catch(() => ""));
await page.screenshot({ path: path.join(OUT, "tela.png"), fullPage: true }).catch(() => {});

salvar(
  "links.json",
  JSON.stringify(
    interativos.filter((x) =>
      /oportun|licit|cotac|acesso|public|pregao|busca|consult/i.test(`${x.txt} ${x.href}`)
    ),
    null,
    2
  )
);
salvar("links_todos.json", JSON.stringify(interativos, null, 2));
salvar("frames.json", JSON.stringify(frames, null, 2));
salvar("network_json.json", JSON.stringify(jsonHits, null, 2));

console.log("\n=== RESUMO DA DESCOBERTA ===");
console.log("Frames:", frames.length);
frames.forEach((f) => console.log("  -", f.name || "(sem nome)", f.url.slice(0, 90)));
console.log("Links/botoes relevantes:", JSON.parse(fs.readFileSync(path.join(OUT, "links.json"))).length);
console.log("Respostas JSON/estruturadas capturadas:", jsonHits.length);
jsonHits.slice(0, 15).forEach((h) => console.log("  *", h.status, h.url.slice(0, 100)));
console.log(`\nArquivos salvos em: ${OUT}`);
console.log("Veja tela.png, links.json e network_json.json para finalizar o scraper.");

await browser.close();
