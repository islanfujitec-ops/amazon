// scraper.js — coleta as licitacoes publicas ABERTAS da Petronect.
//
// Estrategia (descoberta por engenharia reversa do portal, jul/2026):
// A pagina publica "lista_licitacoes_publicadas_ft.html" carrega, sem login e sem
// captcha, uma TABELA paginada com todas as licitacoes abertas (colunas:
// Numero, Objeto, Sub-status, Empresa, Abrangencia, Data inicio, Data fim).
// O portal usa protecao anti-bot (Akamai) + e SPA pesado, entao usamos o Playwright
// (Chromium real) para carregar a pagina e percorrer todas as paginas do resultado.
//
// coletarOportunidades() SEMPRE devolve um array (vazio se falhar), para nunca
// derrubar o loop 24h.
import { chromium } from "playwright";

const LIST_PAGE =
  process.env.PETRONECT_URL ||
  "https://www.petronect.com.br/irj/go/km/docs/pccshrcontent/Site%20Content%20(Legacy)/Portal2018/pt/lista_licitacoes_publicadas_ft.html";

// Link publico para o usuario abrir a lista (a Petronect nao expoe deep-link estavel
// por oportunidade; o Numero identifica a licitacao dentro desta pagina).
const LINK_LISTA = LIST_PAGE;

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36";

const MAX_PAGINAS = Number(process.env.MAX_PAGINAS || 80); // trava de seguranca

function lerTabela(page) {
  return page.evaluate(() => {
    const t = document.querySelector("#result_table table");
    if (!t) return { linhas: [], atual: 0, total: 0 };
    const linhas = [...t.querySelectorAll("tbody tr")]
      .map((r) => [...r.querySelectorAll("td")].map((td) => td.innerText.replace(/\s+/g, " ").trim()))
      .filter((c) => c.length >= 7 && /^\d{6,}$/.test(c[0] || ""));
    // pager "Anterior X de Y Proximo"
    const pagerTxt = (document.querySelector("#pager, .pagination")?.innerText || "").replace(/\s+/g, " ");
    const m = pagerTxt.match(/(\d+)\s*de\s*(\d+)/i);
    return { linhas, atual: m ? Number(m[1]) : 0, total: m ? Number(m[2]) : 0 };
  });
}

async function clicarProximo(page) {
  const achou = await page.evaluate(() => {
    const els = [...document.querySelectorAll("#pager a, #pager button, .pagination a, .pagination li, a, button, span, li")];
    const alvo = els.find(
      (e) => /^(pr[óo]ximo|next|›|»)$/i.test((e.innerText || "").trim()) && e.offsetParent !== null && !e.classList.contains("disabled")
    );
    if (alvo) {
      alvo.setAttribute("data-radar-next", "1");
      return true;
    }
    return false;
  });
  if (!achou) return false;
  await page.locator("[data-radar-next='1']").first().click({ timeout: 8000 }).catch(() => {});
  await page.evaluate(() => document.querySelectorAll("[data-radar-next]").forEach((e) => e.removeAttribute("data-radar-next")));
  return true;
}

export async function coletarOportunidades({ headless = true, log = console.log } = {}) {
  const browser = await chromium.launch({ headless });
  const capturadas = [];
  try {
    const ctx = await browser.newContext({ locale: "pt-BR", timezoneId: "America/Sao_Paulo", userAgent: UA });
    const page = await ctx.newPage();

    await page.goto(LIST_PAGE, { waitUntil: "domcontentloaded", timeout: 90000 });

    // Espera a tabela popular (a pagina carrega os dados via OData apos o boot).
    let ok = false;
    for (let i = 0; i < 30; i++) {
      await page.waitForTimeout(2000);
      const { linhas } = await lerTabela(page);
      if (linhas.length) {
        ok = true;
        break;
      }
    }
    if (!ok) {
      log("[scraper] A tabela nao carregou (site fora do ar, mudanca de layout ou IP fora do Brasil).");
      return [];
    }

    // Filtro por estado (Local de entrega), se configurado. O site refiltra no servidor.
    const uf = (process.env.FILTRO_ESTADO || "").trim().toUpperCase();
    if (uf) {
      const aplicou = await page.evaluate((estado) => {
        const s = document.querySelector("#estadoResultTable");
        if (!s) return false;
        s.value = estado;
        s.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }, uf);
      if (aplicou) {
        await page.waitForTimeout(6000); // espera o site refiltrar
        log(`[scraper] Filtro de estado aplicado: ${uf}.`);
      }
    }

    // Percorre todas as paginas coletando as linhas.
    let numeroPaginaAnterior = -1;
    let primeiroNumAnterior = "";
    for (let p = 0; p < MAX_PAGINAS; p++) {
      const { linhas, atual, total } = await lerTabela(page);
      const primeiroNum = linhas[0]?.[0] || "";
      // Protecao contra loop: se a pagina nao avancou, para.
      if (primeiroNum && primeiroNum === primeiroNumAnterior) break;
      primeiroNumAnterior = primeiroNum;

      for (const c of linhas) {
        capturadas.push({
          id: c[0],
          numero: c[0],
          objeto: c[1] || "",
          substatus: c[2] || "",
          empresa: c[3] || "",
          abrangencia: c[4] || "",
          dataInicio: c[5] || "",
          dataFim: c[6] || "",
        });
      }

      if (total && atual >= total) break; // ultima pagina
      const avancou = await clicarProximo(page);
      if (!avancou) break;
      await page.waitForTimeout(2500);
      if (atual === numeroPaginaAnterior) break;
      numeroPaginaAnterior = atual;
    }

    // Normaliza para o formato padrao do restante do sistema + dedup por numero.
    const vistos = new Set();
    const resultado = [];
    for (const o of capturadas) {
      if (!o.id || vistos.has(o.id)) continue;
      vistos.add(o.id);
      resultado.push({
        id: o.id,
        titulo: o.objeto || `Licitacao ${o.numero}`,
        objeto: o.objeto,
        modalidade: o.substatus,
        orgao: o.empresa,
        data: o.dataInicio,
        prazo: o.dataFim,
        numero: o.numero,
        abrangencia: o.abrangencia,
        // Sem deep-link estavel por oportunidade; usamos a lista publica + o numero.
        link: LINK_LISTA,
      });
    }
    return resultado;
  } catch (e) {
    log("[scraper] erro:", e.message);
    return capturadas.length ? capturadas : [];
  } finally {
    await browser.close().catch(() => {});
  }
}

// Execucao direta: node src/scraper.js
if (process.argv[1] && process.argv[1].endsWith("scraper.js")) {
  const headless = !process.argv.includes("--ver");
  console.log("Coletando (pode levar ~1 min percorrendo as paginas)...");
  const ops = await coletarOportunidades({ headless });
  console.log(`\nColetadas ${ops.length} licitacoes abertas.`);
  console.log("Amostra (5):");
  console.log(JSON.stringify(ops.slice(0, 5), null, 2));
}
