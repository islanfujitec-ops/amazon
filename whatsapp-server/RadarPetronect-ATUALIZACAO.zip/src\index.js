// index.js — orquestrador 24h.
// Ciclo: raspar -> filtrar por palavra-chave -> deduplicar -> resumir (IA) -> enviar no WhatsApp.
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { coletarOportunidades } from "./scraper.js";
import { carregarPalavras, casar } from "./matcher.js";
import { resumir } from "./summarizer.js";
import { enviarMensagem } from "./whatsapp.js";
import {
  jaEnviado,
  marcarEnviado,
  marcarConhecidos,
  ehPrimeiraRodada,
  encerrarPrimeiraRodada,
} from "./store.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const LOG_DIR = path.join(__dirname, "..", "logs");
const LOG_FILE = path.join(LOG_DIR, "radar.log");

const RODAR_UMA_VEZ = process.argv.includes("--once");

// Lidos a cada ciclo (assim o Painel pode mudar sem reiniciar o processo).
const cfgIntervaloMin = () => Number(process.env.INTERVALO_MIN || 15);
const cfgMaxEnvios = () => Number(process.env.MAX_ENVIOS_POR_CICLO || 8);
const cfgHeadless = () => String(process.env.HEADLESS ?? "true") !== "false";
const cfgEnviarNaPrimeira = () => String(process.env.ENVIAR_NA_PRIMEIRA ?? "false") === "true";

function log(...args) {
  const linha = `[${new Date().toISOString()}] ${args.join(" ")}`;
  console.log(linha);
  try {
    if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
    fs.appendFileSync(LOG_FILE, linha + "\n");
  } catch {
    /* ignora erro de log */
  }
}

function montarMensagem(op, resumo, palavras) {
  const linhas = [
    "🛎️ *Nova licitação Petronect*",
    "",
    `*Título:* ${op.titulo || "(sem título)"}`,
  ];
  if (op.numero) linhas.push(`*Nº da oportunidade:* ${op.numero}`);
  if (op.modalidade) linhas.push(`*Situação:* ${op.modalidade}`);
  if (op.orgao) linhas.push(`*Órgão:* ${op.orgao}`);
  if (op.abrangencia) linhas.push(`*Abrangência:* ${op.abrangencia}`);
  linhas.push("");
  linhas.push(`*Resumo:* ${resumo || op.objeto || "(sem resumo)"}`);
  if (op.data) linhas.push(`*Início das propostas:* ${op.data}`);
  if (op.prazo) linhas.push(`*Prazo final:* ${op.prazo}`);
  if (palavras?.length) linhas.push(`_(palavras: ${palavras.join(", ")})_`);
  if (op.link) {
    linhas.push("");
    linhas.push(`🔗 Ver na Petronect (busque pelo nº ${op.numero}):`);
    linhas.push(op.link);
  }
  return linhas.join("\n");
}

export async function umCiclo() {
  const MAX_ENVIOS = cfgMaxEnvios();
  const HEADLESS = cfgHeadless();
  const ENVIAR_NA_PRIMEIRA = cfgEnviarNaPrimeira();

  const palavras = carregarPalavras();
  if (palavras.length === 0) {
    log("AVISO: nenhuma palavra-chave em config/palavras.txt — nada a monitorar.");
    return;
  }

  log(`Iniciando varredura (headless=${HEADLESS}, ${palavras.length} palavras).`);
  let oportunidades = [];
  try {
    oportunidades = await coletarOportunidades({ headless: HEADLESS, log });
  } catch (e) {
    log("ERRO no scraper:", e.message);
    return; // nao derruba o servico; tenta no proximo ciclo
  }
  log(`Coletadas ${oportunidades.length} oportunidades no portal.`);

  // Filtra por palavra-chave.
  const relevantes = [];
  for (const op of oportunidades) {
    const bateu = casar(op, palavras);
    if (bateu.length) relevantes.push({ op, bateu });
  }
  log(`${relevantes.length} casaram com as palavras-chave.`);

  // 1a rodada: so registra o que ja existe (evita enxurrada), salvo se ENVIAR_NA_PRIMEIRA=true.
  if (ehPrimeiraRodada() && !ENVIAR_NA_PRIMEIRA) {
    marcarConhecidos(oportunidades.map((o) => o.id));
    encerrarPrimeiraRodada();
    log(
      `Primeira rodada: registradas ${oportunidades.length} oportunidades como conhecidas SEM enviar. ` +
        `A partir de agora, apenas novidades serao enviadas.`
    );
    return;
  }

  // Envia apenas os novos (nao enviados ainda), respeitando o teto por ciclo.
  const novos = relevantes.filter(({ op }) => !jaEnviado(op.id));
  log(`${novos.length} novos para enviar (teto do ciclo: ${MAX_ENVIOS}).`);

  let enviados = 0;
  for (const { op, bateu } of novos) {
    if (enviados >= MAX_ENVIOS) {
      log(`Teto de ${MAX_ENVIOS} atingido; o restante vai no proximo ciclo.`);
      break;
    }
    try {
      const resumo = await resumir(op); // pode ser null -> cai pro objeto
      const msg = montarMensagem(op, resumo, bateu);
      await enviarMensagem(process.env.WHATSAPP_DESTINO, msg);
      marcarEnviado(op.id, {
        titulo: op.titulo,
        numero: op.numero,
        objeto: op.objeto,
        prazo: op.prazo,
        link: op.link,
        palavras: bateu,
      });
      enviados++;
      log(`Enviado: ${op.titulo?.slice(0, 70) || op.id}`);
    } catch (e) {
      log(`ERRO ao enviar (${op.id}): ${e.message}`);
      // nao marca como enviado -> tenta de novo no proximo ciclo
    }
  }
  if (ehPrimeiraRodada()) encerrarPrimeiraRodada();
  log(`Ciclo concluido. Enviados: ${enviados}.`);
}

async function main() {
  log("==== Radar Petronect iniciado ====");
  log(`Destino WhatsApp: ${process.env.WHATSAPP_DESTINO || "(NAO CONFIGURADO)"}`);

  await umCiclo();

  if (RODAR_UMA_VEZ) {
    log("Modo --once: encerrando.");
    process.exit(0);
  }

  const intervaloMin = cfgIntervaloMin();
  log(`Proxima varredura em ${intervaloMin} min. Deixe esta janela aberta (ou use o Painel/servico).`);
  setInterval(() => {
    umCiclo().catch((e) => log("ERRO inesperado no ciclo:", e.message));
  }, intervaloMin * 60 * 1000);
}

// So roda o loop sozinho quando executado direto (node src/index.js).
// Quando o Painel importa umCiclo(), NAO auto-inicia.
if (process.argv[1] && process.argv[1].endsWith("index.js")) {
  main().catch((e) => {
    log("ERRO fatal:", e.message);
    process.exit(1);
  });
}
