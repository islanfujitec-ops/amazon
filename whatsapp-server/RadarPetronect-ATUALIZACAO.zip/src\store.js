// store.js — deduplicacao simples em arquivo JSON.
// Guarda os IDs das oportunidades ja enviadas para nao repetir alerta.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, "..", "data");
const FILE = path.join(DATA_DIR, "seen.json");

function garantirPasta() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
}

function carregar() {
  garantirPasta();
  if (!fs.existsSync(FILE)) return { ids: {}, primeiraRodada: true };
  try {
    return JSON.parse(fs.readFileSync(FILE, "utf8"));
  } catch {
    return { ids: {}, primeiraRodada: true };
  }
}

function salvar(estado) {
  garantirPasta();
  fs.writeFileSync(FILE, JSON.stringify(estado, null, 2), "utf8");
}

let estado = carregar();

export function jaEnviado(id) {
  return Boolean(estado.ids[id]);
}

export function marcarEnviado(id, meta = {}) {
  estado.ids[id] = { em: new Date().toISOString(), marcado: false, ...meta };
  salvar(estado);
}

// Lista as oportunidades realmente ENCONTRADAS/enviadas (nao as so registradas
// na 1a rodada), mais recentes primeiro. Usada pela aba "Encontradas" do painel.
export function listarEncontradas() {
  return Object.entries(estado.ids)
    .filter(([, v]) => v && !v.somenteRegistrado)
    .map(([id, v]) => ({ id, ...v }))
    .sort((a, b) => String(b.em || "").localeCompare(String(a.em || "")));
}

// Alterna a marcacao (checkbox) de um item. Devolve o novo valor (ou null).
export function alternarMarcado(id) {
  if (!estado.ids[id]) return null;
  estado.ids[id].marcado = !estado.ids[id].marcado;
  salvar(estado);
  return estado.ids[id].marcado;
}

// Marca varios ids como "ja conhecidos" sem enviar (usado na 1a rodada).
export function marcarConhecidos(ids) {
  for (const id of ids) {
    if (!estado.ids[id]) estado.ids[id] = { em: new Date().toISOString(), somenteRegistrado: true };
  }
  salvar(estado);
}

export function ehPrimeiraRodada() {
  return estado.primeiraRodada === true;
}

export function encerrarPrimeiraRodada() {
  estado.primeiraRodada = false;
  salvar(estado);
}

export function totalConhecidos() {
  return Object.keys(estado.ids).length;
}

// Zera o historico (esquece tudo que ja foi visto/enviado) e volta a 1a rodada.
// Usado pelo botao "Enviar licitacoes atuais agora" do painel.
export function resetar() {
  estado = { ids: {}, primeiraRodada: true };
  salvar(estado);
}
