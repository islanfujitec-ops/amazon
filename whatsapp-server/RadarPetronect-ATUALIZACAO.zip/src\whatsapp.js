// whatsapp.js — envio de mensagens via whatsapp-web.js (auto-hospedado).
// Na 1a vez mostra um QR code no terminal: escaneie com o WhatsApp do celular
// (Aparelhos conectados > Conectar aparelho). A sessao fica salva em
// data/.wwebjs_auth e nao precisa escanear de novo.
import "dotenv/config";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import qrcode from "qrcode-terminal";
import { chromium } from "playwright";
import pkg from "whatsapp-web.js";

const { Client, LocalAuth } = pkg;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const AUTH_DIR = path.join(__dirname, "..", "data", ".wwebjs_auth");

// Reaproveita o Chromium do Playwright (ja instalado) para o whatsapp-web.js,
// evitando um segundo download. Se nao achar, deixa o puppeteer usar o proprio.
function acharChromium() {
  if (process.env.WA_CHROME_PATH) return process.env.WA_CHROME_PATH;
  try {
    const ep = chromium.executablePath();
    if (ep && fs.existsSync(ep)) return ep;
  } catch {
    /* ignora */
  }
  return undefined; // puppeteer usa o Chromium dele
}

// Converte o destino configurado em um chatId valido.
// "5521999998888" -> "5521999998888@c.us" | ja com @c.us/@g.us -> inalterado.
export function normalizarDestino(dest) {
  const d = String(dest || "").trim();
  if (!d) return null;
  if (d.includes("@")) return d;
  const digitos = d.replace(/\D/g, "");
  return digitos ? `${digitos}@c.us` : null;
}

// Remove travas ("SingletonLock" etc.) deixadas por um fechamento abrupto do
// navegador, que causariam o erro "The browser is already running for ...".
// Seguro aqui porque so este processo usa esta pasta de sessao.
function limparTravas() {
  try {
    const sessao = path.join(AUTH_DIR, "session");
    if (!fs.existsSync(sessao)) return;
    // "SingletonLock" (Linux/Mac) e "lockfile" (Windows) sobram apos fechamento abrupto.
    for (const nome of fs.readdirSync(sessao)) {
      if (nome.startsWith("Singleton") || nome === "lockfile") {
        fs.rmSync(path.join(sessao, nome), { force: true, recursive: true });
      }
    }
  } catch {
    /* ignora */
  }
}

// Estado compartilhado (lido pelo Painel web para mostrar QR/status/grupo).
//   status: "iniciando" | "aguardando_qr" | "conectado" | "desconectado"
//   qrRaw: string do QR atual (null quando conectado)
//   ultimoGrupo: { id, nome } do ultimo grupo em que chegou/saiu mensagem
const estado = { status: "parado", qrRaw: null, ultimoGrupo: null };
export function getEstado() {
  return { status: estado.status, temQr: !!estado.qrRaw, ultimoGrupo: estado.ultimoGrupo };
}
export function getQrRaw() {
  return estado.qrRaw;
}

let clientePromise = null;

// Cria (ou reaproveita) um cliente WhatsApp pronto para enviar.
export function obterCliente() {
  if (clientePromise) return clientePromise;

  limparTravas();
  estado.status = "iniciando";
  clientePromise = new Promise((resolve, reject) => {
    const execPath = acharChromium();
    const client = new Client({
      authStrategy: new LocalAuth({ dataPath: AUTH_DIR }),
      puppeteer: {
        headless: true,
        executablePath: execPath, // Chromium do Playwright (undefined = usa o do puppeteer)
        args: ["--no-sandbox", "--disable-setuid-sandbox"],
      },
    });

    client.on("qr", (qr) => {
      estado.status = "aguardando_qr";
      estado.qrRaw = qr;
      console.log("\n[WhatsApp] Escaneie o QR abaixo com o app (Aparelhos conectados):\n");
      qrcode.generate(qr, { small: true });
    });
    client.on("authenticated", () => console.log("[WhatsApp] Autenticado."));
    client.on("auth_failure", (m) => console.error("[WhatsApp] Falha de autenticacao:", m));
    client.on("ready", () => {
      estado.status = "conectado";
      estado.qrRaw = null;
      console.log("[WhatsApp] Conectado e pronto.");
      resolve(client);
    });
    client.on("disconnected", (r) => {
      estado.status = "desconectado";
      console.error("[WhatsApp] Desconectado:", r, "- reinicie o processo para reconectar.");
    });

    // Captura o ultimo grupo com atividade (para o Painel oferecer "usar este grupo").
    const capturarGrupo = async (msg) => {
      try {
        const cands = [msg.from, msg.to, msg.id && msg.id.remote].filter(Boolean);
        const gid = cands.find((x) => String(x).endsWith("@g.us"));
        if (!gid) return;
        let nome = "";
        try {
          const chat = await msg.getChat();
          nome = chat?.name || "";
        } catch {
          /* getChat pode falhar; segue so com id */
        }
        estado.ultimoGrupo = { id: gid, nome };
      } catch {
        /* ignora */
      }
    };
    client.on("message_create", capturarGrupo);
    client.on("message", capturarGrupo);

    client.initialize().catch(reject);
  });

  return clientePromise;
}

// Espera a confirmacao do servidor (ack >= 1) para garantir que a mensagem
// realmente saiu, antes de o chamador poder fechar o navegador. Resolve com o
// nivel de ack alcancado (ou o ultimo conhecido, no timeout).
function esperarAck(client, msg, timeoutMs = 20000) {
  return new Promise((resolve) => {
    if (msg && typeof msg.ack === "number" && msg.ack >= 1) return resolve(msg.ack);
    let nivel = (msg && msg.ack) || 0;
    const onAck = (m) => {
      try {
        if (m?.id?._serialized === msg?.id?._serialized) {
          nivel = m.ack;
          if (m.ack >= 1) finalizar();
        }
      } catch {
        /* ignora */
      }
    };
    const finalizar = () => {
      clearTimeout(t);
      client.removeListener("message_ack", onAck);
      resolve(nivel);
    };
    const t = setTimeout(finalizar, timeoutMs);
    client.on("message_ack", onAck);
  });
}

export async function enviarMensagem(destino, texto) {
  const raw = String(destino || "").trim();
  if (!raw) throw new Error("WHATSAPP_DESTINO vazio (defina no .env).");
  const client = await obterCliente();
  let chatId;
  if (raw.includes("@")) {
    chatId = raw; // grupo (@g.us) ou id ja pronto
  } else {
    // Resolve o id real pelo proprio WhatsApp (lida com o esquema novo "LID").
    // Montar "numero@c.us" na mao causa o erro "No LID for user".
    const digitos = raw.replace(/\D/g, "");
    const numId = await client.getNumberId(digitos);
    if (!numId) throw new Error(`O numero ${digitos} nao esta no WhatsApp (confira DDI 55 + DDD).`);
    chatId = numId._serialized;
  }
  const msg = await client.sendMessage(chatId, texto);
  const ack = await esperarAck(client, msg); // 0=pendente 1=servidor 2=entregue 3=lida
  if (ack < 1) throw new Error("A mensagem nao foi confirmada pelo servidor (ack 0). Verifique a conexao/sessao.");
  return ack;
}

// Execucao direta:
//   node src/whatsapp.js --setup   -> so conecta e mostra o QR (parear o celular)
//   node src/whatsapp.js --grupos  -> lista seus grupos e os ids (@g.us) p/ o .env
//   node src/whatsapp.js --test    -> conecta e envia uma mensagem de teste
if (process.argv[1] && process.argv[1].endsWith("whatsapp.js")) {
  const modo = process.argv.includes("--test")
    ? "test"
    : process.argv.includes("--grupos")
      ? "grupos"
      : process.argv.includes("--ouvir")
        ? "ouvir"
        : "setup";
  const client = await obterCliente();
  if (modo === "test") {
    const destino = process.env.WHATSAPP_DESTINO;
    try {
      const ack = await enviarMensagem(destino, "✅ Teste do Radar Petronect: se voce recebeu isto, o WhatsApp esta configurado.");
      console.log(`[WhatsApp] Mensagem CONFIRMADA pelo servidor (ack=${ack}) para ${destino}`);
    } catch (e) {
      console.error("[WhatsApp] Falha ao enviar:", e.message);
    } finally {
      await client.destroy().catch(() => {}); // fecha o navegador (evita processo preso)
      process.exit(0);
    }
  } else if (modo === "grupos") {
    try {
      const chats = await client.getChats();
      const grupos = chats.filter((c) => c.isGroup);
      if (!grupos.length) {
        console.log("\n[WhatsApp] Nenhum grupo encontrado. Crie um grupo no celular e rode de novo.\n");
      } else {
        console.log("\n=== SEUS GRUPOS (copie o id do que voce quer usar) ===\n");
        for (const g of grupos) {
          console.log(`  "${g.name}"`);
          console.log(`     id: ${g.id._serialized}\n`);
        }
        console.log("Cole o id (termina em @g.us) na linha WHATSAPP_DESTINO do .env\n");
      }
    } catch (e) {
      console.error("[WhatsApp] Erro ao listar grupos:", e.message);
    } finally {
      await client.destroy().catch(() => {});
      process.exit(0);
    }
  } else if (modo === "ouvir") {
    // Descobre o id de um grupo pela mensagem que o usuario enviar nele.
    // Mais robusto que getChats() (que falha em algumas versoes do WhatsApp Web).
    console.log("\n>>> Agora ENVIE qualquer mensagem no grupo pelo seu celular (ex.: 'oi').");
    console.log(">>> Aguardando... (ate 2 min)\n");
    let achou = false;
    const capturar = (msg) => {
      const cands = [msg.from, msg.to, msg.id && msg.id.remote].filter(Boolean);
      const gid = cands.find((x) => String(x).endsWith("@g.us"));
      if (gid && !achou) {
        achou = true;
        console.log("=======================================");
        console.log("GRUPO DETECTADO -> id:", gid);
        console.log("=======================================\n");
        client.destroy().catch(() => {}).finally(() => process.exit(0));
      }
    };
    client.on("message_create", capturar);
    client.on("message", capturar);
    setTimeout(() => {
      if (!achou) {
        console.log("[WhatsApp] Tempo esgotado. Rode de novo e envie a mensagem no grupo.");
        client.destroy().catch(() => {}).finally(() => process.exit(1));
      }
    }, 120000);
  } else {
    console.log("[WhatsApp] Pareamento concluido. Sessao salva. Pode fechar (Ctrl+C).");
  }
}
